# Max Jankowski
# CSD-325
# Bellevue university


import requests

response = requests.get('http://www.google.com')
print(response.status_code)